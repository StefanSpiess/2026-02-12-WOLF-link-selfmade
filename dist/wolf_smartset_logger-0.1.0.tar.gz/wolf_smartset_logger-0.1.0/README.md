# Wolf Smartset Logger

Python-Library und CLI-Tools zum automatischen Loggen von Heizungsdaten (Wolf Wärmepumpe) in eine SQLite-Datenbank.

## Features

- ✅ **OAuth2 PKCE Login** (vollautomatisch)
- ✅ **Datenerfassung**: Temperaturen, Verbrauch, JAZ (Jahresarbeitszahl)
- ✅ **Wetterdaten-Integration** (DWD API): Wind, Temperatur, Niederschlag, Sonnenschein
- ✅ **SQLite-Datenbank** für historische Daten
- ✅ **CSV-Export** für Excel/LibreOffice
- ✅ **Abfrage-Tools** mit Statistiken
- ✅ **Mehrfache Messungen pro Tag** für detaillierte Wetter- und Verbrauchsanalyse
- ✅ **Pip-installierbar** als Python-Package mit CLI-Commands

## Installation

### Empfohlen: Als Package installieren (lokal)

```bash
# Repository klonen und ins Verzeichnis wechseln
cd wolf-logger

# Virtual Environment erstellen (optional aber empfohlen)
python -m venv venv
source venv/bin/activate

# Package im Development-Modus installieren
pip install -e .

# Credentials konfigurieren
cp .env.template .env
nano .env  # Username, Password, System-ID und Gateway-ID eintragen
```

Nach der Installation stehen CLI-Commands zur Verfügung:
- `wolf-logger` - Daten loggen
- `wolf-query` - Daten abfragen
- `wolf-export` - CSV-Export

### Alternative: Klassische Installation (Legacy)

```bash
cd wolf-logger
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.template .env
nano .env
```

Dann die Scripts direkt ausführen: `python wolf_logger.py`


**Inhalt der `.env` Datei:**
```env
WOLF_USERNAME=dein_username
WOLF_PASSWORD=dein_password
WOLF_SYSTEM_ID=deine_system_id
WOLF_GATEWAY_ID=deine_gateway_id

# Optional: DWD Wetterstation (Deutscher Wetterdienst)
# Stationsliste: https://www.dwd.de/DE/leistungen/klimadatendeutschland/stationsliste.html
# Beispiele: G005 (München), E438 (Bassum), 10865 (Stuttgart), 10382 (Frankfurt)
DWD_STATION_ID=
```

> **Hinweis:** System-ID und Gateway-ID findest du im Wolf Smartset Portal oder in der Browser-Konsole.

> **Wetterdaten:** Die DWD-Integration ist optional. Wenn `DWD_STATION_ID` nicht gesetzt ist, werden nur Heizungsdaten geloggt. Die Wetterdaten (Temperatur, Wind, Niederschlag, Sonnenschein) helfen beim Analysieren des Verbrauchsverhaltens.

## Verwendung

### CLI-Commands (empfohlen)

Nach der Installation mit `pip install -e .` stehen diese Commands zur Verfügung:

#### 1. Daten loggen

```bash
wolf-logger
```

Das Command:
1. Führt OAuth2 PKCE Login durch
2. Holt aktuelle Heizungsdaten vom Wolf Smartset Portal
3. Speichert Daten in SQLite-Datenbank (`data/wolf.db`)
4. Hängt eine Zeile an CSV-Datei an (`data/wolf.csv`)

#### 2. Daten abfragen

```bash
# Letzte 10 Einträge anzeigen
wolf-query

# Alle Einträge von heute
wolf-query today

# Statistik der letzten 7 Tage (Durchschnittswerte)
wolf-query stats

# Statistik der letzten 30 Tage
wolf-query stats 30

# Letzte 50 Einträge
wolf-query latest 50
```

**Ausgabe-Beispiel:**

```
[2026-02-12 10:30:15]
  Temperaturen:  Vorlauf 46.4°C | Rücklauf 39.9°C | Kessel 46.4°C | Außen 5.2°C
  Verbrauch:     Jahr 1250 kWh (Strom)
  Wärmemenge:    Heizung 4850 kWh | Warmwasser 950 kWh
  JAZ:           4.64
```

#### 3. CSV-Export

```bash
# Alle Daten aus SQLite in CSV exportieren
wolf-export

# Mit benutzerdefiniertem Dateinamen
wolf-export data/meine_daten.csv
```

### Legacy Scripts (weiterhin unterstützt)

Die alten Scripts funktionieren weiterhin für Rückwärtskompatibilität:

```bash
# Daten loggen
python wolf_logger.py

# Daten abfragen
python query_data.py
python query_data.py today
python query_data.py stats 30

# CSV-Export
python export_csv.py
```

## Automatisches Logging mit Cron

Für kontinuierliche Datenerfassung kann ein Cronjob eingerichtet werden:

```bash
# Crontab bearbeiten
crontab -e
```

**Mit CLI-Command (empfohlen nach `pip install -e .`):**
```cron
# Alle 15 Minuten
*/15 * * * * cd /pfad/zum/wolf-logger && source venv/bin/activate && wolf-logger >> logs/cron.log 2>&1

# Täglich um 6:00 Uhr
0 6 * * * cd /pfad/zum/wolf-logger && source venv/bin/activate && wolf-logger >> logs/cron.log 2>&1
```

**Mit Legacy-Script:**
```cron
*/15 * * * * cd /pfad/zum/wolf-logger && ./venv/bin/python wolf_logger.py >> logs/cron.log 2>&1
```

**Logs-Ordner erstellen:**
```bash
mkdir -p logs
```

> **💡 Tipp:** Mit Wetterdaten-Integration sind mehrere Messungen pro Tag erwünscht! Die Wetterdaten ändern sich über den Tag und ermöglichen detaillierte Korrelationen mit dem Heizungsverbrauch. Empfohlen: Logging alle 15-30 Minuten.

## Gespeicherte Daten

Die folgenden Metriken werden pro Messung in der Datenbank gespeichert:

| Feld | Beschreibung | Einheit | Spalte in DB |
|------|--------------|---------|--------------|
| Zeitstempel | Zeitpunkt der Messung | ISO 8601 | `timestamp` |
| Vorlauftemperatur | Kesseltemperatur Vorlauf | °C | `vorlauftemperatur` |
| Rücklauftemperatur | Rücklauftemperatur | °C | `ruecklauftemperatur` |
| Kesseltemperatur | Kesseltemperatur | °C | `kesseltemperatur` |
| Außentemperatur | Außentemperatur | °C | `aussentemperatur` |
| Gesamtverbrauch Jahr | Stromverbrauch aktuelles Jahr | kWh | `gesamtverbrauch` |
| Wärmemenge Heizung | Erzeugte Wärmemenge für Heizung | kWh | `waermemenge_heizung` |
| Wärmemenge Warmwasser | Erzeugte Wärmemenge für Warmwasser | kWh | `waermemenge_warmwasser` |
| Verbrauch Vortag | Verbrauch des Vortages | kWh | `verbrauch_vortag` |
| Verbrauch aktueller Monat | Verbrauch im aktuellen Monat | kWh | `verbrauch_aktueller_monat` |
| Erzeugte Wärmemenge Jahr | Gesamte erzeugte Wärmemenge | kWh | `erzeugte_waermemenge_jahr` |
| JAZ | Jahresarbeitszahl | - | `jaz` |

### Wetterdaten (optional, DWD)

Falls `DWD_STATION_ID` konfiguriert ist, werden zusätzlich folgende Wetterdaten gespeichert:

| Feld | Beschreibung | Einheit | Spalte in DB |
|------|--------------|---------|--------------|
| DWD Station | ID der Wetterstation | - | `dwd_station_id` |
| Temperatur (aktuell) | Aktuelle Temperatur | °C | `dwd_temperature_current` |
| Temperatur (Min) | Tagesminimum | °C | `dwd_temperature_min` |
| Temperatur (Max) | Tagesmaximum | °C | `dwd_temperature_max` |
| Windgeschwindigkeit | Durchschnittliche Windgeschwindigkeit | m/s | `dwd_wind_speed` |
| Windböen | Maximale Windböen | m/s | `dwd_wind_gust` |
| Windrichtung | Windrichtung | ° | `dwd_wind_direction` |
| Niederschlag | Niederschlagsmenge (täglich) | mm | `dwd_precipitation_daily` |
| Sonnenschein | Sonnenscheindauer | Sekunden | `dwd_sunshine_minutes` |
| Luftfeuchtigkeit | Relative Luftfeuchtigkeit | % | `dwd_humidity` |
| Luftdruck | Luftdruck | hPa | `dwd_pressure` |

## Datenbank direkt abfragen

Falls `sqlite3` installiert ist:

```bash
# Alle Daten anzeigen
sqlite3 data/wolf.db "SELECT * FROM heating_data;"

# Letzte 5 Messungen
sqlite3 data/wolf.db "SELECT timestamp, vorlauftemperatur, aussentemperatur, jaz FROM heating_data ORDER BY timestamp DESC LIMIT 5;"

# Durchschnitt der letzten 24h
sqlite3 data/wolf.db "SELECT AVG(vorlauftemperatur), AVG(aussentemperatur), AVG(jaz) FROM heating_data WHERE timestamp >= datetime('now', '-1 day');"
```

## Als Python-Library nutzen

Nach der Installation mit `pip install -e .` kann die Library in eigenen Python-Scripten verwendet werden:

```python
from wolf_smartset import WolfLogger, DWDWeatherClient, database

# Logger erstellen
wolf = WolfLogger()

# Einloggen
wolf.login()

# GUI-Daten holen
gui_data = wolf.get_gui_description()
metrics = wolf.extract_key_metrics(gui_data)

# Optional: Wetterdaten hinzufügen
weather = DWDWeatherClient(station_id="G005")
weather_metrics = weather.get_weather_metrics()
metrics.update(weather_metrics)

# In Datenbank speichern
database.init_database()
row_id = database.save_metrics_to_db(metrics)

print(f"Außentemperatur: {metrics['aussentemperatur']}°C")
print(f"JAZ: {metrics['jaz']}")
print(f"Gespeichert als Row ID: {row_id}")
```

### Datenbank-Funktionen

```python
from wolf_smartset import database

# Datenbank initialisieren
database.init_database("data/wolf.db")

# Letzte Einträge abfragen
rows = database.query_latest(limit=10)

# Heute's Daten
rows = database.query_today()

# Statistiken
stats = database.query_stats(days=7)

# CSV-Export
database.export_to_csv(csv_path="export.csv")
```

## Projektstruktur

```
wolf-logger/
├── wolf_smartset/              # Hauptpackage
│   ├── __init__.py            # Öffentliche API
│   ├── client.py              # WolfLogger-Client (OAuth2, API)
│   ├── weather.py             # DWD Wetterdaten-Client
│   ├── database.py            # Datenbank-Operationen
│   └── cli/                   # CLI-Commands
│       ├── __init__.py
│       ├── logger.py          # wolf-logger command
│       ├── query.py           # wolf-query command
│       └── export.py          # wolf-export command
├── wolf_logger.py             # Legacy-Wrapper (Rückwärtskompatibilität)
├── query_data.py              # Legacy-Wrapper
├── export_csv.py              # Legacy-Wrapper
├── dwd_weather.py             # Legacy-Wrapper
├── test_login.py              # Login-Test-Script
├── pyproject.toml             # Package-Konfiguration (pip)
├── requirements.txt           # Dependencies
├── .env.template              # Vorlage für Konfiguration
├── .env                       # Credentials (nicht im Git!)
├── .gitignore                 # Git-Ignore-Regeln
├── README.md                  # Diese Dokumentation
├── data/
│   ├── wolf.db               # SQLite-Datenbank (wird automatisch erstellt)
│   └── wolf.csv              # CSV-Ausgabe (wird automatisch befüllt)
└── logs/
    └── cron.log              # Cronjob-Logs (optional)
```

## Exit Codes

Das Script gibt verschiedene Exit Codes zurück, die für Cronjobs nützlich sind:

| Exit Code | Bedeutung | Beschreibung | Retry? |
|-----------|-----------|--------------|--------|
| `0` | Erfolg | Daten erfolgreich geloggt | - |
| `1` | Fehler | Login-Fehler, falsche Credentials | Nein |
| `2` | Temporär | Portal-Wartung, Verbindungsfehler | Ja |
| `130` | Abbruch | Benutzer-Abbruch (Ctrl+C) | - |

**Cronjob mit intelligentem Retry:**
```bash
#!/bin/bash
cd /pfad/zum/wolf-logger
./venv/bin/python3 wolf_logger.py
EXIT_CODE=$?

if [ $EXIT_CODE -eq 2 ]; then
    # Temporärer Fehler - in 10 Minuten erneut versuchen
    sleep 600
    ./venv/bin/python3 wolf_logger.py
fi
```

## Troubleshooting

**"WOLF_USERNAME and WOLF_PASSWORD must be set"**
→ `.env` Datei erstellen und Credentials eintragen

**"Token expired or missing"**
→ Normal. Script loggt sich automatisch neu ein.

**"Session ungültig"**
→ Prüfe, ob System-ID und Gateway-ID in `.env` korrekt sind.

**⚠️ Portal-Wartung**
→ Das Wolf Portal führt regelmäßig Wartungsarbeiten durch:
```
⚠️ PORTAL MAINTENANCE
Wartungsarbeiten am Portalserver!
Bitte versuchen Sie es später erneut.
```
→ Das Script beendet sich mit Exit Code `2` (temporärer Fehler)  
→ Cronjobs können automatisch retries machen

**Portal nicht erreichbar**
→ Bei Verbindungsproblemen:
```
⚠️ VERBINDUNGSFEHLER
Das Wolf Portal ist nicht erreichbar.
```
→ Internetverbindung prüfen  
→ https://www.wolf-smartset.com im Browser testen  
→ Später erneut versuchen (Exit Code `2`)

**Login fehlgeschlagen**
→ Bei falschen Zugangsdaten:
```
❌ LOGIN FEHLGESCHLAGEN
Benutzername oder Passwort ungültig.
```
→ Credentials in `.env` überprüfen  
→ Im Browser testen: https://www.wolf-smartset.com  

**Mehrere Einträge pro Tag**
→ Das ist erwünscht! Mit Wetterdaten-Integration sind mehrere Messungen wichtig für detaillierte Analysen.

**CSV-Datei zu groß**
→ Exportiere nur relevante Zeiträume mit `query_data.py` und weiterleiteter Ausgabe:
```bash
python3 query_data.py latest 1000 > export.txt
```

**DWD-Station finden**
→ Teste verschiedene Stationen in deiner Nähe:
```python
import requests
response = requests.get("https://app-prod-ws.warnwetter.de/v30/stationOverviewExtended?stationIds=E438")
print(response.json())
```

## Sicherheit

- `.env` Datei wird **nicht** ins Git committed (siehe `.gitignore`)
- Credentials nur lokal gespeichert
- OAuth2 PKCE Flow für sichere Authentifizierung
- Access Token läuft nach 1 Stunde ab (automatisches Re-Login)

## Credits

Entwickelt für Wolf Smartset Portal: https://www.wolf-smartset.com

## Lizenz

MIT
